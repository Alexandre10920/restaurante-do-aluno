# Mini 3D LAN (Edição Tática & Battle Royale)

Jogo 3D multiplayer para computadores na mesma rede local (LAN).

## Instalar e Iniciar

```bash
npm install
npm start
```

Abra `http://localhost:3000` no computador servidor e o endereço `LAN` mostrado no terminal nos outros computadores da rede.

## Mapas Disponíveis

Escolha o mapa no menu inicial ou pressione **M** durante a partida para trocar e reiniciar a sala:
- **Floresta (Clássico)** — Colinas, árvores, pedras e cabanas.
- **Cidade (Centro Urbano)** — Avenidas cruzadas, prédios acessíveis, carros e guaritas.
- **Favela (Becos e Lajes)** — Casas de tijolo empilhadas, escadas para subir nas lajes, caixas d'água e vielas estreitas.
- **Dust Arena (Estilo CS)** — Bombsites A e B, Meio com portão duplo, caixas de cobertura e varanda.
- **Tactical Site (Estilo Valorant)** — Pátio central geométrico, caixas de Radianita e ângulos táticos.

## Modos de Jogo

- **Modo Livre (Infinito)** — Partida contínua sem limite de abates.
- **Modo Pontos (Mata-Mata)** — Escolha a meta de kills (ex.: 10, 20, 30...). Quem atingir o total exato vence a partida com tela de troféu e reinício automático.

## Controles

- **W A S D** — movimentação
- **Ctrl** — agachar (segure)
- **Shift** — correr (segure junto com W)
- **Espaço** — pular (aperte de novo no ar para pulo duplo)
- **Clique esquerdo** — atirar / atacar
- **Clique direito** — mirar (zoom suave sobre o ombro e precisão aumentada)
- **R** — recarregar
- **E** — pegar item/arma ou usar kit médico
- **Q** — soltar item
- **M** — abrir opções de mapa e modo de jogo
- **1 a 5 / Scroll** — selecionar slot
