const express = require("express");
const http = require("http");
const path = require("path");
const os = require("os");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

const PORT = process.env.PORT || 3000;
const players = new Map();
const priv = new Map(); // estado interno por jogador
const worldItems = new Map(); // id -> { id, type, x, y, z, ammo? }

// ========== ITENS E ARMAS ==========
const WEAPONS = {
  faca: {
    name: "Faca", color: "#cfd8dc", emoji: "🔪", weapon: true,
    damage: 34, pellets: 1, spread: 0, cooldown: 0.45, mag: 0, reload: 0,
    range: 3.4, auto: false, headshot: 1
  },
  pistola: {
    name: "Pistola", color: "#90a4ae", emoji: "🔫", weapon: true,
    damage: 24, pellets: 1, spread: 0.008, cooldown: 0.24, mag: 12, reload: 1.3,
    range: 130, auto: false, headshot: 2
  },
  espingarda: {
    name: "Espingarda", color: "#ff8c42", emoji: "💥", weapon: true,
    damage: 10, pellets: 8, spread: 0.065, cooldown: 0.85, mag: 6, reload: 2.2,
    range: 48, auto: false, headshot: 1.5
  },
  rifle: {
    name: "Rifle", color: "#54d66f", emoji: "🎯", weapon: true,
    damage: 16, pellets: 1, spread: 0.015, cooldown: 0.1, mag: 30, reload: 2.0,
    range: 160, auto: true, headshot: 1.8
  },
  sniper: {
    name: "Sniper", color: "#5dade2", emoji: "🔭", weapon: true,
    // Hipfire bem impreciso (estilo sniper real); mirando fica preciso via spreadScale no tiro
    damage: 72, pellets: 1, spread: 0.11, cooldown: 1.35, mag: 5, reload: 2.8,
    range: 280, auto: false, headshot: 2.2
  }
};

const MEDKIT = { name: "Kit Médico", color: "#ff4d6d", emoji: "➕", weapon: false, heal: 50 };
const COLETE = { name: "Colete", color: "#3498db", emoji: "🦺", weapon: false, armor: 50 };
const MAX_KITS = 3;
const MAX_ARMOR = 100;
const HEAL_MS = 2000;
const ITEM_TYPES = { ...WEAPONS, kit: MEDKIT, colete: COLETE };

const STAND_H = 2.2;
const CROUCH_H = 1.6;
const INVENTORY_SIZE = 5;
const MAX_HP = 100;
const RESPAWN_MS = 3000;
const INVULN_MS = 2500;
const SCORE_MODES = new Set(["pontos", "snipe"]); // modos com meta de kills
const BR_MODES = new Set(["br"]);

// Estado Battle Royale (caminhão + zona)
let brState = {
  active: false,
  phase: "idle", // idle | drop | fight
  truck: { x: 0, y: 80, z: -160, yaw: 0 },
  truckSpeed: 38,
  dropEndsAt: 0,
  zone: { x: 0, z: 0, r: 200, targetR: 200, shrinkEndsAt: 0 },
  zoneTick: null,
  truckTick: null
};
let nextItemId = 1;

const Terrain = require("./public/terrain.js");

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function boxFrom(x, y, z, sx, sy, sz) {
  return { min: [x - sx / 2, y - sy / 2, z - sz / 2], max: [x + sx / 2, y + sy / 2, z + sz / 2] };
}

// Helper para criar prédio/casa com porta e teto escalável
function addBuilding(obstacles, cx, cz, w, d, h, wallColor, roofColor, doorSide = "S", hasInteriorCover = true) {
  const T = 0.5;
  const doorW = 2.4;
  // Norte (z - d/2)
  if (doorSide === "N") {
    const seg = (w - doorW) / 2;
    obstacles.push([cx - w / 2 + seg / 2, h / 2, cz - d / 2, seg, h, T, wallColor]);
    obstacles.push([cx + w / 2 - seg / 2, h / 2, cz - d / 2, seg, h, T, wallColor]);
  } else {
    obstacles.push([cx, h / 2, cz - d / 2, w, h, T, wallColor]);
  }
  // Sul (z + d/2)
  if (doorSide === "S") {
    const seg = (w - doorW) / 2;
    obstacles.push([cx - w / 2 + seg / 2, h / 2, cz + d / 2, seg, h, T, wallColor]);
    obstacles.push([cx + w / 2 - seg / 2, h / 2, cz + d / 2, seg, h, T, wallColor]);
  } else {
    obstacles.push([cx, h / 2, cz + d / 2, w, h, T, wallColor]);
  }
  // Oeste (x - w/2)
  if (doorSide === "W") {
    const seg = (d - doorW) / 2;
    obstacles.push([cx - w / 2, h / 2, cz - d / 2 + seg / 2, T, h, seg, wallColor]);
    obstacles.push([cx - w / 2, h / 2, cz + d / 2 - seg / 2, T, h, seg, wallColor]);
  } else {
    obstacles.push([cx - w / 2, h / 2, cz, T, h, d, wallColor]);
  }
  // Leste (x + w/2)
  if (doorSide === "E") {
    const seg = (d - doorW) / 2;
    obstacles.push([cx + w / 2, h / 2, cz - d / 2 + seg / 2, T, h, seg, wallColor]);
    obstacles.push([cx + w / 2, h / 2, cz + d / 2 - seg / 2, T, h, seg, wallColor]);
  } else {
    obstacles.push([cx + w / 2, h / 2, cz, T, h, d, wallColor]);
  }
  // Teto
  obstacles.push([cx, h + 0.2, cz, w + 0.6, 0.4, d + 0.6, roofColor]);
  if (hasInteriorCover) {
    obstacles.push([cx - w * 0.22, 0.6, cz - d * 0.22, 1.3, 1.2, 1.3, 0x6d4c41]);
  }
}

// Helper para adicionar perímetro fechado em mapas urbanos/táticos
function addPerimeterWalls(obstacles, half, wallColor) {
  const h = 7;
  const len = half * 2 + 2;
  obstacles.push([0, h / 2, -half, len, h, 1.5, wallColor]);
  obstacles.push([0, h / 2, half, len, h, 1.5, wallColor]);
  obstacles.push([-half, h / 2, 0, 1.5, h, len, wallColor]);
  obstacles.push([half, h / 2, 0, 1.5, h, len, wallColor]);
}

const MAP_DEFS = {
  floresta: { name: "Floresta (Clássico)", theme: "forest" },
  cidade:   { name: "Cidade (Centro Urbano)", theme: "city" },
  favela:   { name: "Favela (Becos e Lajes)", theme: "favela" },
  dust:     { name: "Dust Arena (Estilo CS)", theme: "dust" },
  haven:    { name: "Tactical Site (Estilo Valorant)", theme: "valorant" },
  bermuda:  { name: "Bermuda (Battle Royale)", theme: "br" }
};

function generateMapData(mapId) {
  const id = MAP_DEFS[mapId] ? mapId : "floresta";
  const info = MAP_DEFS[id];

  if (id === "floresta") {
    const HALF = 100;
    const rand = mulberry32(20261117);
    const rr = (a, b) => a + rand() * (b - a);
    const gauss = () => Math.sqrt(-2 * Math.log(rand() + 1e-9)) * Math.cos(2 * Math.PI * rand());

    const obstacles = [
      [-18, 1.5, -14, 4, 3, 4, 0x8b5a2b],
      [12, 1.5, -10, 5, 3, 3, 0x7c4a21],
      [-8, 1, 16, 3, 2, 6, 0x6d4c41],
      [20, 2, 14, 5, 4, 5, 0x795548],
      [-25, 1.8, 5, 3.5, 3.6, 3.5, 0x8d6e63],
      [5, 1.2, -28, 6, 2.4, 3, 0x5d4037],
      [28, 2.5, -5, 4, 5, 4, 0x6d4c41],
      [-12, 1.5, 28, 4, 3, 4, 0x795548],
      [0, 1, 0, 2, 2, 2, 0x4e342e]
    ];
    const flats = [];
    obstacles.forEach(([x, , z, sx, , sz]) => {
      const r0 = Math.hypot(sx, sz) / 2 + 1.5;
      flats.push([x, z, r0, r0 + 18]);
    });

    const cabinSpots = [[-45, 40], [52, -48], [58, 55], [-62, -52]];
    cabinSpots.forEach(([cx, cz]) => {
      addBuilding(obstacles, cx, cz, 10, 8, 3.4, 0x8d6e4b, 0x4e3322, "S", true);
      flats.push([cx, cz, 9, 28]);
    });

    const palette = [0x8b5a2b, 0x7c4a21, 0x6d4c41, 0x795548, 0x8d6e63, 0x5d4037];
    for (let i = 0, tries = 0; i < 18 && tries < 400; tries++) {
      const x = rr(-68, 68), z = rr(-68, 68);
      if (flats.some(([fx, fz, r0]) => Math.hypot(x - fx, z - fz) < r0 + 16)) continue;
      const sx = rr(2, 4.5), sy = rr(1.5, 3.2), sz = rr(2, 6);
      obstacles.push([x, sy / 2, z, sx, sy, sz, palette[i % palette.length]]);
      const r0 = Math.hypot(sx, sz) / 2 + 1.5;
      flats.push([x, z, r0, r0 + 18]);
      i++;
    }

    const hills = [];
    for (let i = 0; i < 26; i++) {
      hills.push([rr(-HALF, HALF), rr(-HALF, HALF), rr(10, 22), rr(2, 6)]);
    }

    const terrainParams = { half: HALF, hills, flats, flatGround: false };
    const hFn = Terrain.create(terrainParams);
    const nearFlat = (x, z, pad, outer) =>
      flats.some(([fx, fz, r0, r1]) => Math.hypot(x - fx, z - fz) < (outer ? r1 : r0) + pad);

    const trees = [];
    const forests = Array.from({ length: 12 }, () => [rr(-HALF + 15, HALF - 15), rr(-HALF + 15, HALF - 15)]);
    for (let tries = 0; trees.length < 340 && tries < 4000; tries++) {
      let x, z;
      if (rand() < 0.7) {
        const f = forests[Math.floor(rand() * forests.length)];
        x = f[0] + gauss() * 12; z = f[1] + gauss() * 12;
      } else {
        x = rr(-HALF + 4, HALF - 4); z = rr(-HALF + 4, HALF - 4);
      }
      if (Math.abs(x) > HALF - 4 || Math.abs(z) > HALF - 4) continue;
      if (nearFlat(x, z, 7, false)) continue;
      if (trees.some(([tx, tz]) => Math.hypot(x - tx, z - tz) < 2.4)) continue;
      trees.push([Math.round(x * 10) / 10, Math.round(z * 10) / 10, Math.round(rr(0.8, 1.5) * 100) / 100, rand() < 0.55 ? 1 : 0]);
    }

    const rocks = [];
    for (let tries = 0; rocks.length < 70 && tries < 1000; tries++) {
      const x = rr(-HALF + 4, HALF - 4), z = rr(-HALF + 4, HALF - 4);
      if (nearFlat(x, z, 1.5, false)) continue;
      if (trees.some(([tx, tz]) => Math.hypot(x - tx, z - tz) < 2.2)) continue;
      rocks.push([Math.round(x * 10) / 10, Math.round(z * 10) / 10, Math.round(rr(0.7, 2.2) * 100) / 100]);
    }

    const solids = [];
    const canopyBoxes = [];
    trees.forEach(([x, z, s, kind]) => {
      const h = hFn(x, z);
      solids.push([x, h + 1.2 * s, z, 0.9 * s, 2.4 * s, 0.9 * s]);
      if (kind === 0) canopyBoxes.push(boxFrom(x, h + 3.5 * s, z, 3.2 * s, 3.2 * s, 3.2 * s));
      else canopyBoxes.push(boxFrom(x, h + 4.2 * s, z, 2.6 * s, 5 * s, 2.6 * s));
    });
    rocks.forEach(([x, z, s]) => {
      solids.push([x, hFn(x, z) + 0.4 * s, z, 1.7 * s, 1.2 * s, 1.7 * s]);
    });

    const lootSpots = cabinSpots.map(([cx, cz]) => [cx + 1.5, cz + 1]);
    return {
      id, name: info.name, theme: info.theme, half: HALF,
      terrain: terrainParams, obstacles, trees, rocks, solids, canopyBoxes, lootSpots
    };
  }

  if (id === "cidade") {
    const HALF = 75;
    const obstacles = [];
    addPerimeterWalls(obstacles, HALF, 0x546e7a);

    // Ruas em cruz (asfalto) e calçadas/quarteirões
    obstacles.push([0, 0.03, 0, 16, 0.06, HALF * 2 - 2, 0x2c3138]); // Avenida Norte-Sul
    obstacles.push([0, 0.03, 0, HALF * 2 - 2, 0.06, 16, 0x2c3138]); // Avenida Leste-Oeste
    // Faixas amarelas centrais
    for (let z = -66; z <= 66; z += 8) {
      if (Math.abs(z) > 9) obstacles.push([0, 0.065, z, 0.35, 0.02, 3.5, 0xffca28]);
    }
    for (let x = -66; x <= 66; x += 8) {
      if (Math.abs(x) > 9) obstacles.push([x, 0.065, 0, 3.5, 0.02, 0.35, 0xffca28]);
    }

    // Prédios nos 4 quarteirões com portas voltadas para as avenidas
    const buildings = [
      [-28, -28, 16, 14, 9, 0x78909c, 0x37474f, "S"],
      [-52, -26, 14, 16, 12, 0x90a4ae, 0x455a64, "E"],
      [-30, -52, 18, 12, 7, 0xb0bec5, 0x37474f, "S"],
      [28, -28, 16, 14, 10, 0x8d6e63, 0x4e342e, "S"],
      [52, -26, 14, 16, 8, 0xa1887f, 0x3e2723, "W"],
      [30, -52, 18, 12, 11, 0x78909c, 0x263238, "S"],
      [-28, 28, 16, 14, 8, 0x90a4ae, 0x37474f, "N"],
      [-52, 26, 14, 16, 11, 0x78909c, 0x263238, "E"],
      [-30, 52, 18, 12, 9, 0x8d6e63, 0x4e342e, "N"],
      [28, 28, 16, 14, 12, 0xb0bec5, 0x455a64, "N"],
      [52, 26, 14, 16, 7, 0x90a4ae, 0x37474f, "W"],
      [30, 52, 18, 12, 10, 0xa1887f, 0x3e2723, "N"]
    ];
    buildings.forEach(([x, z, w, d, h, wc, rc, door]) => {
      addBuilding(obstacles, x, z, w, d, h, wc, rc, door, true);
    });

    // Carros / barricadas nas ruas para cobertura tática
    const cars = [
      [-4, 0.85, -22, 2.4, 1.7, 4.8, 0xd32f2f],
      [4.5, 0.85, 24, 2.4, 1.7, 4.8, 0x1976d2],
      [-24, 0.85, 4, 4.8, 1.7, 2.4, 0xfbc02d],
      [26, 0.85, -4, 4.8, 1.7, 2.4, 0x388e3c],
      [0, 0.9, 0, 2.6, 1.8, 2.6, 0x455a64] // Guarita central
    ];
    cars.forEach((c) => obstacles.push(c));

    // Muretas e pontos de cobertura nos becos entre prédios
    obstacles.push([-40, 1.1, -14, 4, 2.2, 1, 0x607d8b]);
    obstacles.push([40, 1.1, 14, 4, 2.2, 1, 0x607d8b]);
    obstacles.push([-14, 1.1, 40, 1, 2.2, 4, 0x607d8b]);
    obstacles.push([14, 1.1, -40, 1, 2.2, 4, 0x607d8b]);

    const terrainParams = { half: HALF, hills: [], flats: [], flatGround: true };
    const lootSpots = buildings.map(([x, z]) => [x, z]);
    return {
      id, name: info.name, theme: info.theme, half: HALF,
      terrain: terrainParams, obstacles, trees: [], rocks: [], solids: [], canopyBoxes: [], lootSpots
    };
  }

  if (id === "favela") {
    const HALF = 68;
    const obstacles = [];
    addPerimeterWalls(obstacles, HALF, 0x8d5524);

    // Casas de tijolo aparente e lajes empilhadas com becos estreitos e vielas
    const brickColors = [0xb55239, 0xc86446, 0xa0452e, 0xd47a55, 0x8d6e63, 0x9e5a40];
    const roofColors = [0x5d4037, 0x4e342e, 0x616161, 0x757575];
    const houses = [
      [-18, -16, 8, 7, 3.2, 0, "E"],
      [-18, -3, 8, 7, 3.2, 1, "S"],
      [-18, 12, 9, 7, 3.2, 2, "E"],
      [-18, 26, 8, 8, 3.2, 3, "N"],
      [-34, -22, 9, 8, 3.2, 4, "S"],
      [-34, -6, 8, 9, 3.2, 5, "E"],
      [-34, 14, 9, 8, 3.2, 0, "N"],
      [-34, 30, 9, 8, 3.2, 1, "E"],
      [18, -18, 8, 7, 3.2, 2, "W"],
      [18, -4, 8, 7, 3.2, 3, "N"],
      [18, 12, 9, 7, 3.2, 4, "W"],
      [18, 28, 8, 8, 3.2, 5, "N"],
      [34, -22, 9, 8, 3.2, 1, "S"],
      [34, -5, 8, 9, 3.2, 2, "W"],
      [34, 15, 9, 8, 3.2, 3, "N"],
      [34, 30, 9, 8, 3.2, 4, "W"],
      [0, -34, 10, 7, 3.2, 0, "S"],
      [0, 34, 10, 7, 3.2, 2, "N"]
    ];

    houses.forEach(([x, z, w, d, h, ci, door], idx) => {
      addBuilding(obstacles, x, z, w, d, h, brickColors[ci % brickColors.length], roofColors[idx % roofColors.length], door, true);
      // Segundo andar (laje) em algumas casas
      if (idx % 3 === 0) {
        addBuilding(obstacles, x, z, w * 0.75, d * 0.75, 2.8, brickColors[(ci + 2) % brickColors.length], 0x424242, door, false);
        // Ajuste da altura do 2º andar para ficar em cima da laje
        const startIdx = obstacles.length - 6;
        for (let k = startIdx; k < obstacles.length; k++) {
          obstacles[k][1] += h + 0.2;
        }
      }
      // Escada / rampa de blocos para subir nas lajes
      if (idx % 2 === 0) {
        const sideX = x > 0 ? x - w / 2 - 1.1 : x + w / 2 + 1.1;
        obstacles.push([sideX, 0.55, z - 1.5, 1.8, 1.1, 1.4, 0x757575]);
        obstacles.push([sideX, 1.1, z, 1.8, 2.2, 1.4, 0x757575]);
        obstacles.push([sideX, 1.65, z + 1.5, 1.8, 3.3, 1.4, 0x757575]);
      }
    });

    // Caixa d'água azul icônica em cima de algumas lajes + muretas nos becos
    obstacles.push([-18, 4.3, -16, 1.6, 1.6, 1.6, 0x0288d1]);
    obstacles.push([18, 4.3, 12, 1.6, 1.6, 1.6, 0x0288d1]);
    obstacles.push([0, 4.3, -34, 1.6, 1.6, 1.6, 0x0288d1]);

    // Coberturas na viela central
    obstacles.push([-3, 1.0, -10, 2.5, 2.0, 1.2, 0x8d6e63]);
    obstacles.push([3, 1.0, 8, 2.5, 2.0, 1.2, 0x8d6e63]);
    obstacles.push([0, 0.8, 0, 2.2, 1.6, 2.2, 0x6d4c41]);
    obstacles.push([-4, 1.0, 20, 2.6, 2.0, 1.2, 0x757575]);
    obstacles.push([4, 1.0, -22, 2.6, 2.0, 1.2, 0x757575]);

    const terrainParams = { half: HALF, hills: [], flats: [], flatGround: true };
    const lootSpots = houses.slice(0, 8).map(([x, z]) => [x, z]);
    return {
      id, name: info.name, theme: info.theme, half: HALF,
      terrain: terrainParams, obstacles, trees: [], rocks: [], solids: [], canopyBoxes: [], lootSpots
    };
  }

  if (id === "dust") {
    // Mapa estilo Counter-Strike (Dust II / Bomb Sites A e B, Meio, Túnel, Varanda)
    const HALF = 72;
    const obstacles = [];
    const sandWall = 0xd7b889;
    const sandDark = 0xb89464;
    const crateWood = 0x9e6b3b;
    const crateGreen = 0x4f6d4a;

    addPerimeterWalls(obstacles, HALF, sandDark);

    // Paredes principais dividindo Bombsite A (Oeste), Meio (Centro) e Bombsite B (Leste)
    // Parede entre A e Meio (com passagens Norte, Centro e Sul)
    obstacles.push([-22, 2.5, -42, 2, 5, 24, sandWall]);
    obstacles.push([-22, 2.5, 0, 2, 5, 26, sandWall]);
    obstacles.push([-22, 2.5, 42, 2, 5, 24, sandWall]);

    // Parede entre Meio e B (com passagens Norte, Centro e Sul)
    obstacles.push([22, 2.5, -42, 2, 5, 24, sandWall]);
    obstacles.push([22, 2.5, 0, 2, 5, 26, sandWall]);
    obstacles.push([22, 2.5, 42, 2, 5, 24, sandWall]);

    // Portão duplo no Meio (estilo Mid Doors)
    obstacles.push([-7, 2.4, 0, 11, 4.8, 1.5, sandDark]);
    obstacles.push([7, 2.4, 0, 11, 4.8, 1.5, sandDark]);

    // Bombsite A (lado esquerdo x = -46)
    obstacles.push([-48, 1.5, -18, 4, 3, 4, crateWood]);
    obstacles.push([-42, 1.1, -14, 2.4, 2.2, 2.4, crateGreen]);
    obstacles.push([-52, 1.2, 12, 3.5, 2.4, 3.5, crateWood]);
    obstacles.push([-36, 1.0, 24, 5, 2.0, 1.5, sandDark]); // Mureta da varanda
    // Rampa/plataforma elevada em A
    obstacles.push([-56, 0.75, -36, 16, 1.5, 18, sandDark]);
    obstacles.push([-46, 0.4, -36, 4, 0.8, 6, sandWall]); // Degrau

    // Bombsite B (lado direito x = +46)
    obstacles.push([48, 1.5, -20, 4, 3, 4, crateGreen]);
    obstacles.push([43, 1.1, -15, 2.4, 2.2, 2.4, crateWood]);
    obstacles.push([50, 1.4, 16, 4.2, 2.8, 3.2, crateWood]);
    obstacles.push([36, 1.0, -28, 5, 2.0, 1.5, sandDark]);
    // Túnel coberto em B
    addBuilding(obstacles, 48, 38, 16, 14, 4.2, sandWall, sandDark, "N", true);

    // Coberturas no Meio (Xbox)
    obstacles.push([-4, 1.1, -18, 2.4, 2.2, 2.4, crateWood]);
    obstacles.push([4, 1.1, 18, 2.4, 2.2, 2.4, crateGreen]);
    obstacles.push([0, 0.9, -46, 6, 1.8, 2, sandDark]);
    obstacles.push([0, 0.9, 46, 6, 1.8, 2, sandDark]);

    const terrainParams = { half: HALF, hills: [], flats: [], flatGround: true };
    const lootSpots = [
      [-45, -15], [45, -15], [0, -14], [0, 14],
      [-48, 15], [48, 36], [-32, -38], [32, 38]
    ];
    return {
      id, name: info.name, theme: info.theme, half: HALF,
      terrain: terrainParams, obstacles, trees: [], rocks: [], solids: [], canopyBoxes: [], lootSpots
    };
  }

  if (id === "bermuda") {
    // Mapa grande estilo Free Fire (~360u de diâmetro)
    const HALF = 180;
    const rand = mulberry32(20261119);
    const rr = (a, b) => a + rand() * (b - a);
    const obstacles = [];
    const trees = [];
    const rocks = [];
    const flats = [];
    const hills = [];

    // Colinas suaves espalhadas
    for (let i = 0; i < 28; i++) {
      const hx = rr(-150, 150);
      const hz = rr(-150, 150);
      hills.push([hx, hz, rr(18, 42), rr(2.5, 9)]);
    }

    // POIs principais (cidades / vilas)
    const pois = [
      [0, 0, 22, 18, "centro"],
      [-95, -80, 18, 16, "norte"],
      [100, -70, 16, 14, "leste"],
      [-90, 95, 16, 14, "oeste"],
      [85, 100, 18, 15, "sul"],
      [0, -120, 14, 12, "porto"],
      [0, 125, 14, 12, "fazenda"],
      [-130, 0, 12, 12, "oficina"],
      [130, 20, 12, 12, "torre"]
    ];
    pois.forEach(([cx, cz, w, d]) => {
      addBuilding(obstacles, cx, cz, w, d, rr(3.5, 6.5), 0x8d7355, 0x4a3728, "S", true);
      // prédios satélite
      for (let k = 0; k < 4; k++) {
        const ox = cx + rr(-18, 18);
        const oz = cz + rr(-16, 16);
        if (Math.hypot(ox - cx, oz - cz) < 8) continue;
        addBuilding(obstacles, ox, oz, rr(6, 11), rr(5, 9), rr(2.8, 5), 0x7a6548, 0x3e2f22, ["N", "S", "E", "W"][k % 4], true);
      }
      flats.push([cx, cz, Math.max(w, d) / 2 + 4, 40]);
    });

    // Contêineres e caixas de loot
    for (let i = 0; i < 40; i++) {
      const x = rr(-160, 160), z = rr(-160, 160);
      if (flats.some(([fx, fz, r0]) => Math.hypot(x - fx, z - fz) < r0)) continue;
      obstacles.push([x, 1.1, z, rr(2, 4), rr(1.6, 2.6), rr(2, 5), i % 2 ? 0x2e86c1 : 0xc0392b]);
    }

    // Árvores
    for (let i = 0; i < 120; i++) {
      const x = rr(-165, 165), z = rr(-165, 165);
      if (flats.some(([fx, fz, r0]) => Math.hypot(x - fx, z - fz) < r0 + 2)) continue;
      trees.push([x, z, rr(2.2, 4.5)]);
    }
    for (let i = 0; i < 35; i++) {
      rocks.push([rr(-155, 155), rr(-155, 155), rr(1.2, 3.2)]);
    }

    const lootSpots = pois.map(([x, z]) => [x + rr(-6, 6), z + rr(-6, 6)]);
    // mais loot espalhado
    for (let i = 0; i < 30; i++) lootSpots.push([rr(-150, 150), rr(-150, 150)]);

    const terrainParams = { half: HALF, hills, flats, flatGround: false };
    return {
      id, name: info.name, theme: info.theme, half: HALF,
      terrain: terrainParams, obstacles, trees, rocks, solids: [], canopyBoxes: [], lootSpots
    };
  }

  // id === "haven" (Estilo Valorant - arquitetura limpa, radianite crates, linhas de visão táticas)
  const HALF = 70;
  const obstacles = [];
  const valWall = 0xeceff4;
  const valTrim = 0x3b4252;
  const radianite = 0x00bfa5;
  const valAccent = 0xff4655;

  addPerimeterWalls(obstacles, HALF, valTrim);

  // Estrutura central geométrica (Mid Courtyard)
  obstacles.push([0, 2.2, -16, 14, 4.4, 2, valWall]);
  obstacles.push([0, 2.2, 16, 14, 4.4, 2, valWall]);
  obstacles.push([-16, 2.2, 0, 2, 4.4, 14, valWall]);
  obstacles.push([16, 2.2, 0, 2, 4.4, 14, valWall]);
  // Pilar central com detalhe vermelho Valorant
  obstacles.push([0, 2.5, 0, 4, 5, 4, valTrim]);
  obstacles.push([0, 2.5, 0, 4.2, 0.5, 4.2, valAccent]);

  // Caixas de Radianita (verde-água brilhante) espalhadas nos bombsites
  const radBoxes = [
    [-38, 1.2, -24, 2.6, 2.4, 2.6],
    [-41, 1.2, -21, 2.4, 2.4, 2.4],
    [-38, 3.0, -24, 2.0, 1.4, 2.0],
    [38, 1.2, 24, 2.6, 2.4, 2.6],
    [41, 1.2, 21, 2.4, 2.4, 2.4],
    [-36, 1.2, 28, 2.8, 2.4, 2.8],
    [36, 1.2, -28, 2.8, 2.4, 2.8],
    [-8, 1.1, -8, 2.2, 2.2, 2.2],
    [8, 1.1, 8, 2.2, 2.2, 2.2]
  ];
  radBoxes.forEach(([x, y, z, sx, sy, sz]) => {
    obstacles.push([x, y, z, sx, sy, sz, radianite]);
  });

  // Garagens / salas táticas nos cantos
  addBuilding(obstacles, -46, -44, 16, 14, 4.5, valWall, valTrim, "E", true);
  addBuilding(obstacles, 46, 44, 16, 14, 4.5, valWall, valTrim, "W", true);
  addBuilding(obstacles, -46, 44, 14, 14, 4.5, valWall, valTrim, "N", true);
  addBuilding(obstacles, 46, -44, 14, 14, 4.5, valWall, valTrim, "S", true);

  // Paredes de ângulo / Heaven (estilo Valorant)
  obstacles.push([-28, 2.0, -34, 1.5, 4, 12, valWall]);
  obstacles.push([28, 2.0, 34, 1.5, 4, 12, valWall]);
  obstacles.push([-28, 2.0, 34, 12, 4, 1.5, valWall]);
  obstacles.push([28, 2.0, -34, 12, 4, 1.5, valWall]);

  const terrainParams = { half: HALF, hills: [], flats: [], flatGround: true };
  const lootSpots = [
    [-38, -28], [38, 28], [-38, 24], [38, -24],
    [-46, -44], [46, 44], [0, -10], [0, 10]
  ];
  return {
    id, name: info.name, theme: info.theme, half: HALF,
    terrain: terrainParams, obstacles, trees: [], rocks: [], solids: [], canopyBoxes: [], lootSpots
  };
}

// ========== ESTADO DA PARTIDA (MAPA E MODO DE JOGO) ==========
let gameSettings = {
  mapId: "floresta",
  mode: "livre", // "livre" | "pontos" | "snipe" | "br"
  killTarget: 10
};

function clearBrTimers() {
  if (brState.zoneTick) clearInterval(brState.zoneTick);
  if (brState.truckTick) clearInterval(brState.truckTick);
  brState.zoneTick = null;
  brState.truckTick = null;
}

function stopBr() {
  clearBrTimers();
  brState.active = false;
  brState.phase = "idle";
}

function startBrDrop() {
  stopBr();
  if (gameSettings.mode !== "br") return;
  brState.active = true;
  brState.phase = "drop";
  const half = MAP ? MAP.half : 180;
  // Caminhão voador atravessa o mapa
  brState.truck = { x: -half + 10, y: 72, z: -half * 0.35, yaw: 0.35 };
  brState.truckSpeed = 42;
  brState.dropEndsAt = Date.now() + 45000;
  brState.zone = { x: 0, z: 0, r: half * 1.05, targetR: half * 1.05, shrinkEndsAt: 0 };

  for (const p of players.values()) {
    p.br = { phase: "truck", chute: false }; // truck | chute | grounded
    p.position = { x: brState.truck.x, y: brState.truck.y, z: brState.truck.z };
    p.dead = false;
    p.hp = MAX_HP;
    p.armor = 0;
  }

  io.emit("brState", getBrPublicState());

  brState.truckTick = setInterval(() => {
    if (!brState.active || brState.phase !== "drop") return;
    const t = brState.truck;
    t.x += Math.sin(t.yaw) * brState.truckSpeed * 0.1;
    t.z += Math.cos(t.yaw) * brState.truckSpeed * 0.1;
    // leve curva
    t.yaw += 0.004;

    for (const p of players.values()) {
      if (p.dead || !p.br || p.br.phase !== "truck") continue;
      p.position.x = t.x;
      p.position.y = t.y;
      p.position.z = t.z;
      io.emit("playerMoved", {
        id: p.id,
        position: p.position,
        rotation: p.rotation,
        pitch: p.pitch,
        crouch: false
      });
    }

    io.emit("brTruck", { x: t.x, y: t.y, z: t.z, yaw: t.yaw });

    // força salto perto do fim do mapa / tempo
    if (Date.now() > brState.dropEndsAt || Math.abs(t.x) > half + 20 || Math.abs(t.z) > half + 20) {
      for (const p of players.values()) {
        if (p.br && p.br.phase === "truck") forceBrJump(p);
      }
      beginBrFight();
    }
  }, 100);
}

function getBrPublicState() {
  return {
    active: brState.active,
    phase: brState.phase,
    truck: { ...brState.truck },
    dropEndsAt: brState.dropEndsAt,
    zone: { ...brState.zone },
    alive: [...players.values()].filter((p) => !p.dead).length
  };
}

function forceBrJump(p) {
  if (!p.br || p.br.phase !== "truck") return;
  p.br.phase = "chute";
  p.br.chute = true;
  p.position.y = brState.truck.y - 2;
  io.to(p.id).emit("brJump", { position: p.position });
  io.emit("playerMoved", {
    id: p.id,
    position: p.position,
    rotation: p.rotation,
    pitch: p.pitch,
    crouch: false
  });
}

function beginBrFight() {
  if (brState.phase === "fight") return;
  brState.phase = "fight";
  clearInterval(brState.truckTick);
  brState.truckTick = null;

  // quem ainda no caminhão é empurrado
  for (const p of players.values()) {
    if (p.br && p.br.phase === "truck") forceBrJump(p);
  }

  const half = MAP ? MAP.half : 180;
  brState.zone = {
    x: (Math.random() - 0.5) * half * 0.3,
    z: (Math.random() - 0.5) * half * 0.3,
    r: half * 0.95,
    targetR: half * 0.55,
    shrinkEndsAt: Date.now() + 90000
  };
  io.emit("brState", getBrPublicState());

  // Zona encolhe em etapas + dano fora
  brState.zoneTick = setInterval(() => {
    if (!brState.active || matchOver) return;
    const z = brState.zone;
    const now = Date.now();
    if (now > z.shrinkEndsAt && z.targetR > 18) {
      z.r = z.targetR;
      z.targetR = Math.max(16, z.targetR * 0.55);
      z.x += (Math.random() - 0.5) * z.r * 0.15;
      z.z += (Math.random() - 0.5) * z.r * 0.15;
      z.shrinkEndsAt = now + 75000;
      io.emit("brZone", { ...z });
    } else if (z.r > z.targetR) {
      z.r = Math.max(z.targetR, z.r - 0.35);
      io.emit("brZone", { x: z.x, z: z.z, r: z.r, targetR: z.targetR, shrinkEndsAt: z.shrinkEndsAt });
    }

    // Dano fora da zona
    for (const p of players.values()) {
      if (p.dead || !p.br || p.br.phase === "truck") continue;
      const dx = p.position.x - z.x;
      const dz = p.position.z - z.z;
      if (dx * dx + dz * dz > z.r * z.r) {
        damagePlayer(p, 4, { id: "zone", name: "Zona" }, "zone");
      }
    }

    checkBrWin();
  }, 500);
}

function checkBrWin() {
  if (gameSettings.mode !== "br" || matchOver) return;
  const alive = [...players.values()].filter((p) => !p.dead);
  if (players.size >= 1 && alive.length <= 1 && brState.phase === "fight") {
    const winner = alive[0] || [...players.values()][0];
    if (winner) triggerMatchWin(winner);
  }
}

let matchOver = false;
let winnerInfo = null;
let matchResetTimer = null;

let MAP = null;
let heightAt = () => 0;
let bulletBoxes = [];

function loadMap(mapId) {
  const data = generateMapData(mapId);
  MAP = {
    id: data.id,
    name: data.name,
    theme: data.theme,
    half: data.half,
    terrain: data.terrain,
    obstacles: data.obstacles,
    trees: data.trees,
    rocks: data.rocks,
    solids: data.solids
  };
  heightAt = Terrain.create(MAP.terrain);
  bulletBoxes = [
    ...MAP.obstacles.map(([x, y, z, sx, sy, sz]) => boxFrom(x, y, z, sx, sy, sz)),
    ...MAP.solids.map(([x, y, z, sx, sy, sz]) => boxFrom(x, y, z, sx, sy, sz)),
    ...data.canopyBoxes
  ];

  worldItems.clear();
  nextItemId = 1;
  seedItems(data.lootSpots);
}

function insideSolid(x, z, y, pad) {
  return bulletBoxes.some((b) =>
    x > b.min[0] - pad && x < b.max[0] + pad &&
    z > b.min[2] - pad && z < b.max[2] + pad &&
    b.min[1] < y + 2.2 && b.max[1] > y
  );
}

function spawnPosition() {
  const half = MAP.half;
  let x = 0, z = 0, y = 0;
  for (let i = 0; i < 60; i++) {
    x = Math.round((Math.random() * 2 - 1) * (half - 10) * 10) / 10;
    z = Math.round((Math.random() * 2 - 1) * (half - 10) * 10) / 10;
    y = heightAt(x, z);
    if (!insideSolid(x, z, y, 1.3)) break;
  }
  return { x, y, z };
}

function createStarterInventory() {
  const inv = Array(INVENTORY_SIZE).fill(null);
  if (gameSettings.mode === "snipe") {
    inv[0] = { type: "sniper", ammo: WEAPONS.sniper.mag };
  } else {
    inv[0] = { type: "faca" };
  }
  return inv;
}

function clampMap(v) {
  const half = MAP.half;
  return Math.max(-(half - 3), Math.min(half - 3, v));
}

function spawnWorldItem(type, x, z, ammo) {
  const id = "item_" + nextItemId++;
  const item = {
    id,
    type,
    x: Math.round(clampMap(x) * 10) / 10,
    y: 0,
    z: Math.round(clampMap(z) * 10) / 10
  };
  item.y = Math.round((heightAt(item.x, item.z) + 0.6) * 100) / 100;
  if (ammo !== undefined) item.ammo = ammo;
  worldItems.set(id, item);
  return item;
}

function seedItems(lootSpots = []) {
  const half = MAP.half;
  const snipeOnly = gameSettings.mode === "snipe";

  lootSpots.forEach(([lx, lz], i) => {
    if (!insideSolid(lx, lz, heightAt(lx, lz), 0.8)) {
      if (snipeOnly) {
        spawnWorldItem("sniper", lx, lz);
      } else {
        spawnWorldItem(i % 2 ? "rifle" : "espingarda", lx, lz);
      }
    }
    if (!insideSolid(lx + 1.5, lz, heightAt(lx + 1.5, lz), 0.8)) {
      spawnWorldItem("kit", lx + 1.5, lz);
    }
  });

  const types = snipeOnly
    ? ["sniper", "sniper", "sniper", "sniper"]
    : ["pistola", "pistola", "espingarda", "rifle", "sniper"];
  for (let i = 0, tries = 0; i < 24 && tries < 600; tries++) {
    const x = (Math.random() * 2 - 1) * (half - 8);
    const z = (Math.random() * 2 - 1) * (half - 8);
    if (insideSolid(x, z, heightAt(x, z), 1.4)) continue;
    spawnWorldItem(types[i % types.length], x, z);
    i++;
  }

  for (let i = 0, tries = 0; i < 16 && tries < 600; tries++) {
    const x = (Math.random() * 2 - 1) * (half - 8);
    const z = (Math.random() * 2 - 1) * (half - 8);
    if (insideSolid(x, z, heightAt(x, z), 1.4)) continue;
    spawnWorldItem("kit", x, z);
    i++;
  }

  // Coletes espalhados pelo mapa
  for (let i = 0, tries = 0; i < 12 && tries < 500; tries++) {
    const x = (Math.random() * 2 - 1) * (half - 8);
    const z = (Math.random() * 2 - 1) * (half - 8);
    if (insideSolid(x, z, heightAt(x, z), 1.4)) continue;
    spawnWorldItem("colete", x, z);
    i++;
  }
}

loadMap("floresta");

function randomColor() {
  const colors = ["#4da6ff", "#ff5c5c", "#54d66f", "#ffd24d", "#c77dff", "#ff8c42"];
  return colors[Math.floor(Math.random() * colors.length)];
}

function equippedType(p) {
  const s = p.inventory[p.selected];
  return s && WEAPONS[s.type] && !p.dead ? s.type : null;
}

function updateWeapon(p) {
  const t = equippedType(p);
  if (p.weapon !== t) {
    p.weapon = t;
    io.emit("playerWeapon", { id: p.id, weapon: t });
  }
}

function broadcastScores() {
  const list = [...players.values()]
    .map((p) => ({ id: p.id, name: p.name, kills: p.kills, deaths: p.deaths }))
    .sort((a, b) => b.kills - a.kills || a.deaths - b.deaths);
  io.emit("scores", list);
}

function dropAll(p) {
  p.inventory.forEach((slot) => {
    if (!slot || slot.type === "faca") return;
    const a = Math.random() * Math.PI * 2;
    const r = 0.8 + Math.random() * 1.2;
    const item = spawnWorldItem(slot.type, p.position.x + Math.cos(a) * r, p.position.z + Math.sin(a) * r, slot.ammo);
    io.emit("itemSpawned", item);
  });
  for (let k = 0; k < (p.kits || 0); k++) {
    const a = Math.random() * Math.PI * 2;
    const r = 0.8 + Math.random() * 1.2;
    io.emit("itemSpawned", spawnWorldItem("kit", p.position.x + Math.cos(a) * r, p.position.z + Math.sin(a) * r));
  }
  p.kits = 0;
  if ((p.armor || 0) > 0) {
    const a = Math.random() * Math.PI * 2;
    const r = 0.8 + Math.random() * 1.2;
    io.emit("itemSpawned", spawnWorldItem("colete", p.position.x + Math.cos(a) * r, p.position.z + Math.sin(a) * r));
  }
  p.armor = 0;
}

function resetMatch(newSettings) {
  clearTimeout(matchResetTimer);
  matchOver = false;
  winnerInfo = null;
  stopBr();

  if (newSettings) {
    if (MAP_DEFS[newSettings.mapId]) gameSettings.mapId = newSettings.mapId;
    if (newSettings.mode === "livre" || newSettings.mode === "pontos" || newSettings.mode === "snipe" || newSettings.mode === "br") {
      gameSettings.mode = newSettings.mode;
    }
    const kt = parseInt(newSettings.killTarget, 10);
    if (Number.isFinite(kt) && kt >= 1 && kt <= 100) gameSettings.killTarget = kt;
  }

  // BR força mapa bermuda
  if (gameSettings.mode === "br") gameSettings.mapId = "bermuda";

  loadMap(gameSettings.mapId);

  for (const [id, p] of players) {
    const st = priv.get(id);
    if (st) {
      cancelReload(st);
      cancelHeal(p);
      clearTimeout(st.respawnTimer);
      st.invulnUntil = Date.now() + INVULN_MS;
    }
    p.dead = false;
    p.hp = MAX_HP;
    p.armor = 0;
    p.kills = 0;
    p.deaths = 0;
    p.kits = 0;
    p.crouch = false;
    p.position = spawnPosition();
    p.inventory = createStarterInventory();
    p.selected = 0;
    p.br = null;
    updateWeapon(p);
  }

  io.emit("matchReset", {
    settings: gameSettings,
    map: MAP,
    items: Object.fromEntries(worldItems),
    players: Object.fromEntries(players)
  });
  broadcastScores();

  if (gameSettings.mode === "br") {
    startBrDrop();
    io.emit("brState", getBrPublicState());
  }
}

function triggerMatchWin(winner) {
  if (matchOver) return;
  matchOver = true;
  winnerInfo = {
    id: winner.id,
    name: winner.name,
    kills: winner.kills,
    deaths: winner.deaths,
    killTarget: gameSettings.killTarget
  };
  io.emit("matchWin", winnerInfo);

  // Reinicia automaticamente a partida após 8 segundos
  clearTimeout(matchResetTimer);
  matchResetTimer = setTimeout(() => {
    resetMatch();
  }, 8000);
}

// ========== RAIOS (balas) ==========
function rayBox(o, d, min, max) {
  let tmin = 0;
  let tmax = Infinity;
  for (let i = 0; i < 3; i++) {
    if (Math.abs(d[i]) < 1e-9) {
      if (o[i] < min[i] || o[i] > max[i]) return null;
    } else {
      let t1 = (min[i] - o[i]) / d[i];
      let t2 = (max[i] - o[i]) / d[i];
      if (t1 > t2) { const t = t1; t1 = t2; t2 = t; }
      if (t1 > tmin) tmin = t1;
      if (t2 < tmax) tmax = t2;
      if (tmin > tmax) return null;
    }
  }
  return tmin;
}

function castRay(o, d, maxRange, shooterId) {
  let best = { t: maxRange, kind: 0 };

  let prev = 0;
  for (let t = 1; t <= best.t; t += 1) {
    const y = o[1] + d[1] * t;
    if (y < heightAt(o[0] + d[0] * t, o[2] + d[2] * t)) {
      let lo = prev, hi = t;
      for (let k = 0; k < 8; k++) {
        const m = (lo + hi) / 2;
        if (o[1] + d[1] * m < heightAt(o[0] + d[0] * m, o[2] + d[2] * m)) hi = m; else lo = m;
      }
      if (hi < best.t) best = { t: hi, kind: 1 };
      break;
    }
    prev = t;
    if (y > 40 && d[1] >= 0) break;
  }

  for (const b of bulletBoxes) {
    const t = rayBox(o, d, b.min, b.max);
    if (t !== null && t > 0 && t < best.t) best = { t, kind: 1 };
  }

  for (const [id, pl] of players) {
    if (id === shooterId || pl.dead) continue;
    const ph = pl.crouch ? CROUCH_H : STAND_H;
    const min = [pl.position.x - 0.5, pl.position.y, pl.position.z - 0.4];
    const max = [pl.position.x + 0.5, pl.position.y + ph, pl.position.z + 0.4];
    const t = rayBox(o, d, min, max);
    if (t !== null && t < best.t) {
      const hy = o[1] + d[1] * t;
      best = { t, kind: 2, victim: pl, head: hy >= pl.position.y + ph * 0.74 };
    }
  }

  return best;
}

function isVec3(v) {
  return Array.isArray(v) && v.length === 3 && v.every((n) => typeof n === "number" && Number.isFinite(n));
}

function normalize(v) {
  const len = Math.hypot(v[0], v[1], v[2]) || 1;
  return [v[0] / len, v[1] / len, v[2] / len];
}

const round2 = (n) => Math.round(n * 100) / 100;

// ========== DANO / MORTE / RESPAWN ==========
function damagePlayer(victim, amount, killer, weaponType) {
  const vs = priv.get(victim.id);
  if (!vs || victim.dead || matchOver || Date.now() < vs.invulnUntil) return false;

  cancelHeal(victim);
  let dmg = Math.round(amount);
  const armor = victim.armor || 0;
  if (armor > 0 && dmg > 0) {
    const absorbed = Math.min(armor, dmg);
    victim.armor = armor - absorbed;
    dmg -= absorbed;
    io.emit("playerArmor", { id: victim.id, armor: victim.armor });
  }
  if (dmg > 0) {
    victim.hp = Math.max(0, victim.hp - dmg);
  }
  io.to(victim.id).emit("damaged", { hp: victim.hp, armor: victim.armor || 0, from: killer.id });
  io.emit("playerHp", { id: victim.id, hp: victim.hp });

  if (victim.hp <= 0) {
    killPlayer(victim, killer, weaponType);
    return true;
  }
  return false;
}

function cancelReload(st) {
  clearTimeout(st.reloadTimer);
  st.reloadUntil = 0;
}

function cancelHeal(p) {
  const st = priv.get(p.id);
  if (!st || !st.healTimer) return;
  clearTimeout(st.healTimer);
  st.healTimer = null;
  io.to(p.id).emit("healCancel");
}

function useKit(p) {
  const st = priv.get(p.id);
  if (!st || p.dead || matchOver || st.healTimer) return;
  if (p.kits <= 0 || p.hp >= MAX_HP) return;

  io.to(p.id).emit("healing", HEAL_MS);
  st.healTimer = setTimeout(() => {
    st.healTimer = null;
    if (p.dead || matchOver || !players.has(p.id) || p.kits <= 0) {
      io.to(p.id).emit("healCancel");
      return;
    }
    p.kits--;
    p.hp = Math.min(MAX_HP, p.hp + MEDKIT.heal);
    io.emit("playerHp", { id: p.id, hp: p.hp });
    io.to(p.id).emit("kits", p.kits);
    io.to(p.id).emit("healDone");
  }, HEAL_MS);
}

function killPlayer(victim, killer, weaponType) {
  const vs = priv.get(victim.id);
  victim.dead = true;
  victim.deaths++;
  if (killer && killer.id !== victim.id) killer.kills++;

  cancelReload(vs);
  cancelHeal(victim);
  dropAll(victim);
  io.to(victim.id).emit("kits", 0);
  io.emit("playerArmor", { id: victim.id, armor: 0 });
  victim.inventory = createStarterInventory();
  victim.selected = 0;
  io.to(victim.id).emit("inventoryUpdate", victim.inventory);
  io.to(victim.id).emit("forceSelect", 0);
  updateWeapon(victim);

  io.emit("playerDied", {
    id: victim.id,
    victimName: victim.name,
    killerId: killer ? killer.id : null,
    killerName: killer ? killer.name : "?",
    weapon: weaponType,
    respawnMs: RESPAWN_MS
  });
  broadcastScores();

  // Verifica vitória nos modos com meta de kills
  if (SCORE_MODES.has(gameSettings.mode) && killer && killer.id !== victim.id && killer.kills >= gameSettings.killTarget) {
    triggerMatchWin(killer);
    return;
  }

  // Battle Royale: sem respawn; último vivo vence
  if (gameSettings.mode === "br") {
    io.emit("brState", getBrPublicState());
    checkBrWin();
    return;
  }

  clearTimeout(vs.respawnTimer);
  vs.respawnTimer = setTimeout(() => respawnPlayer(victim), RESPAWN_MS);
}

function respawnPlayer(p) {
  const st = priv.get(p.id);
  if (!st || !players.has(p.id) || matchOver) return;

  p.dead = false;
  p.hp = MAX_HP;
  p.armor = 0;
  p.position = spawnPosition();
  // No modo snipe, inventário já foi resetado na morte para starter; garante sniper
  if (gameSettings.mode === "snipe") {
    p.inventory = createStarterInventory();
    p.selected = 0;
    io.to(p.id).emit("inventoryUpdate", p.inventory);
    io.to(p.id).emit("forceSelect", 0);
  } else {
    p.selected = 0;
  }
  p.crouch = false;
  st.invulnUntil = Date.now() + INVULN_MS;

  io.emit("playerRespawned", { id: p.id, position: p.position, hp: p.hp, armor: 0 });
  io.emit("playerHp", { id: p.id, hp: p.hp });
  io.emit("playerArmor", { id: p.id, armor: 0 });
  updateWeapon(p);
}

function startReload(p) {
  const st = priv.get(p.id);
  if (!st || p.dead || matchOver) return;
  const slot = p.inventory[p.selected];
  const w = slot && WEAPONS[slot.type];
  if (!w || !(w.mag > 0) || slot.ammo >= w.mag) return;
  if (st.reloadUntil > Date.now()) return;

  const ms = w.reload * 1000;
  st.reloadUntil = Date.now() + ms;
  io.to(p.id).emit("reloading", ms);

  clearTimeout(st.reloadTimer);
  st.reloadTimer = setTimeout(() => {
    st.reloadUntil = 0;
    if (!p.dead && p.inventory[p.selected] === slot) {
      slot.ammo = w.mag;
      io.to(p.id).emit("inventoryUpdate", p.inventory);
    }
  }, ms);
}

// ========== SERVIDOR ==========
app.use(express.static(path.join(__dirname, "public")));

io.on("connection", (socket) => {
  const player = {
    id: socket.id,
    name: `Jogador ${players.size + 1}`,
    color: randomColor(),
    position: spawnPosition(),
    rotation: 0,
    pitch: 0,
    inventory: createStarterInventory(),
    selected: 0,
    weapon: null,
    hp: MAX_HP,
    armor: 0,
    kits: 0,
    crouch: false,
    dead: false,
    kills: 0,
    deaths: 0
  };
  player.weapon = equippedType(player);

  players.set(socket.id, player);
  priv.set(socket.id, {
    nextShot: 0,
    reloadUntil: 0,
    reloadTimer: null,
    healTimer: null,
    respawnTimer: null,
    invulnUntil: Date.now() + INVULN_MS
  });

  // Se BR em andamento, novo jogador entra no caminhão se ainda em drop
  if (gameSettings.mode === "br" && brState.active && brState.phase === "drop") {
    player.br = { phase: "truck", chute: false };
    player.position = { x: brState.truck.x, y: brState.truck.y, z: brState.truck.z };
  } else if (gameSettings.mode === "br" && brState.active) {
    player.br = { phase: "grounded", chute: false };
  }

  socket.emit("welcome", {
    id: socket.id,
    player,
    players: Object.fromEntries(players),
    items: Object.fromEntries(worldItems),
    itemTypes: ITEM_TYPES,
    map: MAP,
    mapList: MAP_DEFS,
    settings: gameSettings,
    winner: matchOver ? winnerInfo : null,
    br: brState.active ? getBrPublicState() : null
  });

  socket.broadcast.emit("playerJoined", player);
  broadcastScores();

  socket.on("configureMatch", (cfg) => {
    if (!cfg || typeof cfg !== "object") return;
    const mapChanged = cfg.mapId && MAP_DEFS[cfg.mapId] && cfg.mapId !== gameSettings.mapId;
    const validModes = ["livre", "pontos", "snipe", "br"];
    const modeChanged = validModes.includes(cfg.mode) && cfg.mode !== gameSettings.mode;
    const kt = parseInt(cfg.killTarget, 10);
    const targetChanged = Number.isFinite(kt) && kt >= 1 && kt <= 100 && kt !== gameSettings.killTarget;

    if (mapChanged || modeChanged || targetChanged || cfg.forceRestart) {
      resetMatch(cfg);
      const p = players.get(socket.id);
      let modeLabel = "Modo Livre";
      if (SCORE_MODES.has(gameSettings.mode)) {
        modeLabel = (gameSettings.mode === "snipe" ? "Só Snipe • Meta " : "Meta ") + gameSettings.killTarget + " kills";
      } else if (gameSettings.mode === "br") {
        modeLabel = "Battle Royale";
      }
      io.emit("notice", `${p ? p.name : "Host"} alterou a sala: ${MAP.name} (${modeLabel})`);
    }
  });

  socket.on("setName", (name) => {
    const p = players.get(socket.id);
    if (!p) return;
    const clean = String(name || "").trim().slice(0, 16);
    if (clean) p.name = clean;
    io.emit("playerUpdated", p);
    broadcastScores();
  });

  socket.on("move", (data) => {
    const p = players.get(socket.id);
    if (!p || p.dead || matchOver) return;

    // No caminhão o servidor controla a posição
    if (p.br && p.br.phase === "truck") {
      p.rotation = typeof data?.rotation === "number" ? data.rotation : p.rotation;
      if (typeof data?.pitch === "number" && Number.isFinite(data.pitch)) {
        p.pitch = Math.max(-1.5, Math.min(1.5, data.pitch));
      }
      return;
    }

    if (
      typeof data?.x !== "number" ||
      typeof data?.y !== "number" ||
      typeof data?.z !== "number" ||
      typeof data?.rotation !== "number"
    ) return;

    const half = MAP.half;
    const maxY = (p.br && p.br.phase === "chute") ? 120 : 45;
    p.position.x = Math.max(-(half - 2), Math.min(half - 2, data.x));
    p.position.y = Math.max(-1, Math.min(maxY, data.y));
    p.position.z = Math.max(-(half - 2), Math.min(half - 2, data.z));
    p.rotation = data.rotation;
    p.crouch = data.crouch === true;
    if (typeof data?.pitch === "number" && Number.isFinite(data.pitch)) {
      p.pitch = Math.max(-1.5, Math.min(1.5, data.pitch));
    }

    // Aterrissou de paraquedas
    if (p.br && p.br.phase === "chute") {
      const ground = heightAt(p.position.x, p.position.z);
      if (p.position.y <= ground + 0.6) {
        p.position.y = ground;
        p.br.phase = "grounded";
        p.br.chute = false;
        io.to(p.id).emit("brLanded");
      }
    }

    socket.broadcast.emit("playerMoved", {
      id: p.id,
      position: p.position,
      rotation: p.rotation,
      pitch: p.pitch,
      crouch: p.crouch
    });
  });

  socket.on("brJump", () => {
    const p = players.get(socket.id);
    if (!p || p.dead || matchOver || gameSettings.mode !== "br") return;
    if (!p.br || p.br.phase !== "truck") return;
    forceBrJump(p);
  });

  socket.on("select", (idx) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead || matchOver) return;
    const i = Number(idx);
    if (!Number.isInteger(i) || i < 0 || i >= INVENTORY_SIZE) return;
    if (i !== p.selected) cancelReload(st);
    p.selected = i;
    updateWeapon(p);
  });

  socket.on("pickup", (itemId) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    const item = worldItems.get(itemId);
    if (!p || !item || p.dead || matchOver) return;

    const dx = p.position.x - item.x;
    const dz = p.position.z - item.z;
    if (dx * dx + dz * dz > 9) return;

    if (item.type === "kit") {
      if (p.kits >= MAX_KITS) {
        socket.emit("notice", `Máximo de ${MAX_KITS} kits médicos!`);
        return;
      }
      p.kits++;
      worldItems.delete(itemId);
      io.emit("itemRemoved", itemId);
      socket.emit("kits", p.kits);
      return;
    }

    if (item.type === "colete") {
      if ((p.armor || 0) >= MAX_ARMOR) {
        socket.emit("notice", "Colete já está no máximo!");
        return;
      }
      p.armor = Math.min(MAX_ARMOR, (p.armor || 0) + (COLETE.armor || 50));
      worldItems.delete(itemId);
      io.emit("itemRemoved", itemId);
      io.emit("playerArmor", { id: p.id, armor: p.armor });
      return;
    }

    const slot = p.inventory.findIndex((s) => s === null);
    if (slot === -1) {
      socket.emit("inventoryFull");
      return;
    }

    const w = WEAPONS[item.type];
    const entry = { type: item.type };
    if (w && w.mag > 0) entry.ammo = item.ammo !== undefined ? item.ammo : w.mag;

    p.inventory[slot] = entry;
    worldItems.delete(itemId);

    io.emit("itemRemoved", itemId);
    socket.emit("inventoryUpdate", p.inventory);

    if (w && !WEAPONS[p.inventory[p.selected]?.type]) {
      cancelReload(st);
      p.selected = slot;
      socket.emit("forceSelect", slot);
    }
    updateWeapon(p);
  });

  socket.on("drop", (slotIndex) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead || matchOver) return;

    const idx = Number(slotIndex);
    if (!Number.isInteger(idx) || idx < 0 || idx >= INVENTORY_SIZE) return;
    if (!p.inventory[idx]) return;

    const { type, ammo } = p.inventory[idx];
    p.inventory[idx] = null;
    if (idx === p.selected) cancelReload(st);

    const angle = p.rotation || 0;
    const dropX = p.position.x + Math.sin(angle) * 1.8;
    const dropZ = p.position.z + Math.cos(angle) * 1.8;

    const newItem = spawnWorldItem(type, dropX, dropZ, ammo);
    io.emit("itemSpawned", newItem);
    socket.emit("inventoryUpdate", p.inventory);
    updateWeapon(p);
  });

  socket.on("useKit", () => {
    const p = players.get(socket.id);
    if (p) useKit(p);
  });

  socket.on("reload", () => {
    const p = players.get(socket.id);
    if (p) startReload(p);
  });

  socket.on("shoot", (data) => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (!p || p.dead || matchOver) return;

    const slot = p.inventory[p.selected];
    const w = slot && WEAPONS[slot.type];
    if (!w) return;

    const now = Date.now();
    if (now < st.nextShot || now < st.reloadUntil) return;

    if (!isVec3(data?.origin) || !isVec3(data?.dir)) return;
    const cam = data.origin;
    const dir = normalize(data.dir);

    const eye = [p.position.x, p.position.y + 1.5, p.position.z];
    const toEye = [eye[0] - cam[0], eye[1] - cam[1], eye[2] - cam[2]];
    if (Math.hypot(toEye[0], toEye[1], toEye[2]) > 15) return;

    if (w.mag > 0 && slot.ammo <= 0) {
      socket.emit("emptyClip");
      startReload(p);
      return;
    }

    st.nextShot = now + w.cooldown * 1000 - 40;

    const t0 = Math.max(0, toEye[0] * dir[0] + toEye[1] * dir[1] + toEye[2] * dir[2]);
    const origin = [cam[0] + dir[0] * t0, cam[1] + dir[1] * t0, cam[2] + dir[2] * t0];

    const ends = [];
    const hits = new Map();

    // ADS: sniper fica quase laser; outras armas melhoram moderadamente
    let spreadScale = data.aiming ? 0.35 : 1.0;
    if (slot.type === "sniper") {
      spreadScale = data.aiming ? 0.04 : 1.0;
    }

    for (let i = 0; i < w.pellets; i++) {
      const s = w.spread * spreadScale;
      const d = normalize([
        dir[0] + (Math.random() * 2 - 1) * s,
        dir[1] + (Math.random() * 2 - 1) * s,
        dir[2] + (Math.random() * 2 - 1) * s
      ]);
      const r = castRay(origin, d, w.range, socket.id);

      ends.push([
        round2(origin[0] + d[0] * r.t),
        round2(origin[1] + d[1] * r.t),
        round2(origin[2] + d[2] * r.t),
        r.kind
      ]);

      if (r.kind === 2) {
        const cur = hits.get(r.victim.id) || { victim: r.victim, amount: 0, head: false };
        cur.amount += w.damage * (r.head ? w.headshot : 1);
        cur.head = cur.head || r.head;
        hits.set(r.victim.id, cur);
      }
    }

    if (w.mag > 0) {
      slot.ammo--;
      socket.emit("inventoryUpdate", p.inventory);
    }

    io.emit("shot", { id: p.id, type: slot.type, ends });

    for (const h of hits.values()) {
      const killed = damagePlayer(h.victim, h.amount, p, slot.type);
      socket.emit("hitConfirm", { kill: killed, head: h.head });
      if (matchOver) break;
    }

    if (!matchOver && w.mag > 0 && slot.ammo === 0) startReload(p);
  });

  socket.on("disconnect", () => {
    const p = players.get(socket.id);
    const st = priv.get(socket.id);
    if (st) {
      clearTimeout(st.reloadTimer);
      clearTimeout(st.healTimer);
      clearTimeout(st.respawnTimer);
    }
    if (p && !p.dead && !matchOver) dropAll(p);
    players.delete(socket.id);
    priv.delete(socket.id);
    io.emit("playerLeft", socket.id);
    broadcastScores();
  });
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`
Jogo iniciado na porta ${PORT}`);
  console.log(`Local: http://localhost:${PORT}`);

  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const net of nets[name] || []) {
      if (net.family === "IPv4" && !net.internal) {
        console.log(`LAN:   http://${net.address}:${PORT}`);
      }
    }
  }
});
