// Altura do terreno: usada IGUAL no servidor (balas, spawn) e no cliente (física, visual).
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.Terrain = factory();
})(this, function () {
  function create(map) {
    const { half, hills = [], flats = [], flatGround = false } = map;
    return function heightAt(x, z) {
      if (flatGround) {
        // Cordilheira/muros suaves apenas bem fora do limite
        const e = Math.max(Math.abs(x), Math.abs(z));
        const t = Math.max(0, Math.min(1, (e - (half + 2)) / 24));
        return 8 * t * t * (3 - 2 * t);
      }

      let h = 0;
      for (let i = 0; i < hills.length; i++) {
        const [hx, hz, s, a] = hills[i];
        const dx = x - hx;
        const dz = z - hz;
        const d2 = dx * dx + dz * dz;
        if (d2 > 9 * s * s) continue;
        h += a * Math.exp(-d2 / (2 * s * s));
      }
      // ondulação suave do terreno
      h += 0.5 * Math.sin(x * 0.09 + 1.3) * Math.cos(z * 0.07 + 0.4);
      h += 0.25 * Math.sin(x * 0.23) * Math.sin(z * 0.19);

      // colinas sobrepostas não passam de ~9 de altura
      h = 9 * Math.tanh(h / 9);

      // áreas planas (construções e caixas)
      let m = 1;
      for (let i = 0; i < flats.length; i++) {
        const [fx, fz, r0, r1] = flats[i];
        const dx = x - fx;
        const dz = z - fz;
        if (Math.abs(dx) >= r1 || Math.abs(dz) >= r1) continue;
        const d = Math.sqrt(dx * dx + dz * dz);
        if (d >= r1) continue;
        if (d <= r0) { m = 0; break; }
        const t = (d - r0) / (r1 - r0);
        m *= t * t * (3 - 2 * t);
      }
      h *= m;

      // cordilheira nas bordas do mapa
      const e = Math.max(Math.abs(x), Math.abs(z));
      const t = Math.max(0, Math.min(1, (e - (half - 26)) / 26));
      h += 11 * t * t * (3 - 2 * t);
      return h;
    };
  }
  return { create };
});
